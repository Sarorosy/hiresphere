<footer class="bg-gray-800 text-white py-4">
    <div class="container mx-auto text-center">
        <p class="text-sm">&copy; <?= date('Y'); ?> HireSphere. All Rights Reserved.</p>
        <p class="text-sm">Powered by <a href="#" class="text-blue-400 hover:underline">HireSphere</a></p>
    </div>
</footer>
</body>
</html>
